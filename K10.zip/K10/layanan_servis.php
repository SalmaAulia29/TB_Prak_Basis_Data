<!-- Tab Layanan Servis -->
<div id="layanan" class="tab-content">
    <h2>Layanan Servis</h2>

    <?php
    include 'koneksi.php';

    // Proses Update Status jika dikirim
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
        $id_layanan = $_POST['id_layanan'];
        $status_baru = $_POST['status_baru'];

        $stmt = $conn->prepare("UPDATE layanan_servis SET status = ? WHERE id_layanan = ?");
        $stmt->bind_param("si", $status_baru, $id_layanan);
        $stmt->execute();
    }

    // Ambil data layanan
    $sql_layanan_all = "SELECT * FROM layanan_servis ORDER BY id_layanan";
    $result_layanan_all = $conn->query($sql_layanan_all);
    ?>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Layanan</th>
                <th>Deskripsi</th>
                <th>Harga</th>
                <th>Estimasi Waktu</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result_layanan_all->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id_layanan']; ?></td>
                    <td><?php echo $row['nama_layanan']; ?></td>
                    <td><?php echo $row['deskripsi']; ?></td>
                    <td>Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></td>
                    <td><?php echo $row['estimasi_waktu']; ?> menit</td>
                    <td>
                        <span class="status-badge status-<?php echo strtolower($row['status']); ?>">
                            <?php echo ucfirst($row['status']); ?>
                        </span>
                    </td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="id_layanan" value="<?php echo $row['id_layanan']; ?>">
                            <select name="status_baru" onchange="this.form.submit()">
                                <option value="Aktif" <?php echo ($row['status'] == 'aktif') ? 'selected' : ''; ?>>Aktif</option>
                                <option value="Nonaktif" <?php echo ($row['status'] == 'nonaktif') ? 'selected' : ''; ?>>Nonaktif</option>
                            </select>
                            <input type="hidden" name="update_status" value="1">
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>